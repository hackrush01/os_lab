base = int(input("Enter base: "))
height = int(input("Enter height: "))
result = 0.5 * base * height

print("Area of triangle is: ", result)
