from math import factorial
num = int(input("Enter the number to find the factorial of: "))
print("Factorial of {0:d} is: {1:d}".format(num,factorial(num)))

