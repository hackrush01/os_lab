dec = int(input("Enter the decimal number: "))

print("Decimal     : ", dec)
print("Binary      : ", bin(dec)[2:])
print("Octal       : ", oct(dec)[2:])
print("Hexadecimal : ", hex(dec)[2:])
