num = int(input("Enter the last num: "))
sumNat = int(num * (num + 1) / 2)

print("Sum of first {0:d} natural numbers is {1:d}".format(num, sumNat))
