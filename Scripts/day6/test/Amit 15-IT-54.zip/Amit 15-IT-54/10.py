celsius = int(input("Enter temp in celsius: "))
fahrenheit = 32 + (9 * celsius) / 5

print("Temp in fahrenheit is: ", fahrenheit)
