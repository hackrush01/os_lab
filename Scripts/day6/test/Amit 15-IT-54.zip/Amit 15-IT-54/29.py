string = input("Enter a string: ").split()
string.sort()
string = " ".join(string)
print(string)
