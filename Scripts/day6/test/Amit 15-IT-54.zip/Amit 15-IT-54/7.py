num1 = int(input("Enter 1st Number: "))
num2 = int(input("Enter 2nd Number: "))
result = num1 + num2

print("Sum is: ", result)