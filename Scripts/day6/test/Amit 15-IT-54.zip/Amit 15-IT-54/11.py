num = int(input("Enter a number: "))

if num < 0:
	print ("The number is negative!")
elif num == 0:
	print ("The number is Zero!")
else:
	print ("The number is Positive!")
